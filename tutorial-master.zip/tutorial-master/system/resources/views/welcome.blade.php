@extends('layout.master')

@section('content')

<div class=container>
<div class="row">
    <h1 class="text-center">Welcome To Merchandiser Web</h1>
    <div class="col-md-4">
     
     </div>
    <div class="col-md-4">

    </div>
    <div class="col-md-4">
     
    </div>
</div>
</div>

@endsection